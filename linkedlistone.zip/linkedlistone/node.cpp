//raymond baartmans
//linked lists one
//node.cpp

#include <iostream>
#include "node.h"
#include "student.h"

using namespace std;

Node::Node(Student*){//construct
  student = NULL; 
  next = NULL;
}

Node::~Node(){//deconstructor
  delete &student;//deletes the student
  next = NULL;//sets next = null
}

void Node::setStudent(Student* newStudent){//set the student
  student = newStudent;//sets student to input
}

Student* Node::getStudent(){//returns student
  return student;
}

void Node::setNext(Node* newNext){//set next node
  next = newNext;//sets next to the inputed node
}

Node* Node::getNext(){//returns the next node
  return next;//returns next node
}
